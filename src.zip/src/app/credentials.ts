// Config
export const credentials = {
	firebaseConfig: {
    apiKey: "AIzaSyB3P8LDBL0yFGEThTlfDsL8X41HrD3MFYE",
    authDomain: "fir-practice-49a13.firebaseapp.com",
    databaseURL: "https://fir-practice-49a13.firebaseio.com",
    projectId: "fir-practice-49a13",
    storageBucket: "",
    messagingSenderId: "974363798806",
		timestampsInSnapshots: true
    },
    // Admin user setup
    adminId: 'e213bJLCkaUVt2d91lups9YgtkX2',
		// Chat Users
		users_endpoint: "chat-users",
  	chats_endpoint: "chats"
};
