import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-detail',
  templateUrl: './bill-detail.page.html',
  styleUrls: ['./bill-detail.page.scss'],
})
export class BillDetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
