import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-create',
  templateUrl: './bill-create.page.html',
  styleUrls: ['./bill-create.page.scss'],
})
export class BillCreatePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
